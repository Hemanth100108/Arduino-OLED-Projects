#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define BUTTON_PIN 2
#define BUZZER_PIN 8

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

int counter = 0;
unsigned long startTime;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (1);
  }

  startTime = millis();

  display.clearDisplay();
  display.display();
}

void loop() {

  // Button Press Detection
  if (digitalRead(BUTTON_PIN) == LOW) {

    counter++;

    tone(BUZZER_PIN, 1000);
    delay(100);
    noTone(BUZZER_PIN);

    while (digitalRead(BUTTON_PIN) == LOW);
    delay(50);
  }

  // Calculate elapsed time
  unsigned long elapsedSeconds =
      (millis() - startTime) / 1000;

  // OLED Dashboard
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(WHITE);

  display.setCursor(15, 0);
  display.println("eARgle Labs");

  display.drawLine(0, 12, 127, 12, WHITE);

  display.setCursor(0, 20);
  display.print("Counter : ");
  display.println(counter);

  display.setCursor(0, 35);
  display.print("Status  : Active");

  display.setCursor(0, 50);
  display.print("Time    : ");
  display.print(elapsedSeconds);
  display.print(" sec");

  display.display();
}