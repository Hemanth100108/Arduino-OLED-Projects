#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define BUTTON_PIN 2
#define BUZZER_PIN 8

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

int count = 0;
bool lastButtonState = HIGH;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();

  showCount();
}

void loop() {
  bool buttonState = digitalRead(BUTTON_PIN);

  // Button Press Detection
  if (buttonState == LOW && lastButtonState == HIGH) {
    count++;

    // Buzzer Beep
    tone(BUZZER_PIN, 1000);
    delay(100);
    noTone(BUZZER_PIN);

    showCount();

    delay(200); // Debounce
  }

  lastButtonState = buttonState;
}

void showCount() {
  display.clearDisplay();

  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(15, 10);
  display.println("COUNT");

  display.setTextSize(4);
  display.setCursor(30, 30);
  display.println(count);

  display.display();
}