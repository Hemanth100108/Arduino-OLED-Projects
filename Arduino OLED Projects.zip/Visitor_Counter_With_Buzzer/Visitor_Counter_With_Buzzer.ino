#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define ENTRY_BUTTON 2
#define EXIT_BUTTON 3
#define BUZZER_PIN 8

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

int peopleCount = 0;

bool lastEntryState = HIGH;
bool lastExitState = HIGH;

void setup() {
  pinMode(ENTRY_BUTTON, INPUT_PULLUP);
  pinMode(EXIT_BUTTON, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (true);
  }

  updateDisplay();
}

void loop() {
  bool entryState = digitalRead(ENTRY_BUTTON);
  bool exitState = digitalRead(EXIT_BUTTON);

  // Entry Button Pressed
  if (entryState == LOW && lastEntryState == HIGH) {

    if (peopleCount < 20) {
      peopleCount++;
      tone(BUZZER_PIN, 1000, 100);   // Normal beep
    }
    else {
      tone(BUZZER_PIN, 2000, 500);   // Room full warning
    }

    updateDisplay();
    delay(200); // Debounce
  }

  // Exit Button Pressed
  if (exitState == LOW && lastExitState == HIGH) {

    if (peopleCount > 0) {
      peopleCount--;
      tone(BUZZER_PIN, 800, 100);    // Exit beep
    }

    updateDisplay();
    delay(200); // Debounce
  }

  lastEntryState = entryState;
  lastExitState = exitState;
}

void updateDisplay() {
  display.clearDisplay();

  display.setTextColor(SSD1306_WHITE);

  // Title
  display.setTextSize(1);
  display.setCursor(15, 0);
  display.println("Visitor Counter");

  // Count
  display.setTextSize(2);
  display.setCursor(0, 20);
  display.print("Inside:");
  display.print(peopleCount);

  // Status
  display.setTextSize(1);
  display.setCursor(20, 52);

  if (peopleCount == 0) {
    display.println("ROOM EMPTY");
  }
  else if (peopleCount >= 20) {
    display.println("ROOM FULL");
  }

  display.display();
}