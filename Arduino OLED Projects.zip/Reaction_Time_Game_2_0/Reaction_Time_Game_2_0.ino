#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define BUTTON_PIN 2

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

unsigned long startTime;
unsigned long reactionTime;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (1);
  }

  randomSeed(analogRead(A0));

  display.clearDisplay();
  display.display();
}

void loop() {

  // Get Ready Screen
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(WHITE);
  display.setCursor(0, 20);
  display.println("GET READY");
  display.display();

  delay(random(2000, 5000));

  // PRESS NOW Screen
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 20);
  display.println("PRESS NOW!");
  display.display();

  startTime = millis();

  // Wait for button press
  while (digitalRead(BUTTON_PIN) == HIGH) {
  }

  reactionTime = millis() - startTime;

  // Result Screen
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 5);
  display.print("Reaction Time:");

  display.setTextSize(2);
  display.setCursor(0, 20);
  display.print(reactionTime);
  display.println(" ms");

  display.setTextSize(1);
  display.setCursor(0, 50);

  if (reactionTime < 250) {
    display.print("Excellent");
  }
  else if (reactionTime <= 500) {
    display.print("Good");
  }
  else {
    display.print("Needs Practice");
  }

  display.display();

  delay(4000);

  // Wait for button release before next round
  while (digitalRead(BUTTON_PIN) == LOW) {
  }
}