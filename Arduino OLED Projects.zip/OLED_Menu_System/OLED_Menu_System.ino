#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define BTN_DOWN   2
#define BTN_SELECT 3

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

int menuIndex = 0;
bool inSubMenu = false;

void showMenu() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // Menu Title
  display.setCursor(25, 0);
  display.println("MAIN MENU");

  // Menu Items
  display.setCursor(0, 18);
  display.print(menuIndex == 0 ? ">" : " ");
  display.println(" LED Control");

  display.setCursor(0, 34);
  display.print(menuIndex == 1 ? ">" : " ");
  display.println(" Buzzer Test");

  display.setCursor(0, 50);
  display.print(menuIndex == 2 ? ">" : " ");
  display.println(" About");

  display.display();
}

void showSelection() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  switch (menuIndex) {

    case 0:
      display.setTextSize(2);
      display.setCursor(10, 20);
      display.println("LED");
      display.println("ON/OFF");
      break;

    case 1:
      display.setTextSize(2);
      display.setCursor(0, 20);
      display.println("BUZZER");
      display.println("TEST");
      break;

    case 2:
      display.setTextSize(1);
      display.setCursor(15, 20);
      display.println("eARgle Labs");
      display.println("");
      display.println("IoT Workshop");
      break;
  }

  display.display();
}

void setup() {
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_SELECT, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (true);
  }

  showMenu();
}

void loop() {

  // Move cursor down
  if (digitalRead(BTN_DOWN) == LOW) {
    delay(200); // debounce

    if (!inSubMenu) {
      menuIndex++;

      if (menuIndex > 2) {
        menuIndex = 0; // wrap around
      }

      showMenu();
    }

    while (digitalRead(BTN_DOWN) == LOW);
  }

  // Select / Back
  if (digitalRead(BTN_SELECT) == LOW) {
    delay(200); // debounce

    if (!inSubMenu) {
      inSubMenu = true;
      showSelection();
    } else {
      inSubMenu = false;
      showMenu();
    }

    while (digitalRead(BTN_SELECT) == LOW);
  }
}