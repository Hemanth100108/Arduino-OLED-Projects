#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define START_BTN 2
#define STOP_BTN 3

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

unsigned long startTime = 0;
unsigned long elapsedTime = 0;
bool running = false;

void setup() {
  pinMode(START_BTN, INPUT_PULLUP);
  pinMode(STOP_BTN, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (1);
  }

  display.clearDisplay();
  display.display();
}

void loop() {

  // Reset (both buttons together)
  if (digitalRead(START_BTN) == LOW &&
      digitalRead(STOP_BTN) == LOW) {

    running = false;
    elapsedTime = 0;
    startTime = 0;
    delay(300);
  }

  // Start / Resume
  if (digitalRead(START_BTN) == LOW &&
      digitalRead(STOP_BTN) == HIGH) {

    if (!running) {
      startTime = millis() - elapsedTime;
      running = true;
    }
    delay(200);
  }

  // Stop / Pause
  if (digitalRead(STOP_BTN) == LOW &&
      digitalRead(START_BTN) == HIGH) {

    if (running) {
      elapsedTime = millis() - startTime;
      running = false;
    }
    delay(200);
  }

  // Update stopwatch
  if (running) {
    elapsedTime = millis() - startTime;
  }

  float seconds = elapsedTime / 1000.0;

  // OLED Display
  display.clearDisplay();

  // Title
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(25, 0);
  display.println("STOPWATCH");

  // Status
  display.setCursor(90, 0);
  if (running)
    display.print("RUN");
  else
    display.print("STOP");

  // Separator
  display.drawLine(0, 12, 127, 12, WHITE);

  // Time
  display.setTextSize(2);
  display.setCursor(10, 28);
  display.print(seconds, 2);
  display.print(" s");

  display.display();
}