#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define BTN1 2
#define BTN2 3
#define BUZZER 8

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Password: Button1, Button1, Button2, Button1
int password[4] = {1, 1, 2, 1};
int entered[4];
int count = 0;

void showPasswordScreen() {
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(10, 10);
  display.println("ENTER PASSWORD");

  display.setCursor(35, 35);

  for (int i = 0; i < count; i++) {
    display.print("* ");
  }

  display.display();
}

void grantedScreen() {
  display.clearDisplay();

  display.setTextSize(2);
  display.setCursor(0, 25);
  display.println("GRANTED");

  display.display();

  tone(BUZZER, 1000);
  delay(700);
  noTone(BUZZER);
}

void deniedScreen() {
  display.clearDisplay();

  display.setTextSize(2);
  display.setCursor(10, 25);
  display.println("DENIED");

  display.display();

  for (int i = 0; i < 3; i++) {
    tone(BUZZER, 500);
    delay(150);
    noTone(BUZZER);
    delay(100);
  }
}

void checkPassword() {

  bool correct = true;

  for (int i = 0; i < 4; i++) {
    if (entered[i] != password[i]) {
      correct = false;
      break;
    }
  }

  if (correct) {
    grantedScreen();
  } else {
    deniedScreen();
  }

  delay(2000);

  count = 0;
  showPasswordScreen();
}

void setup() {

  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BTN2, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (1);
  }

  display.clearDisplay();
  display.display();

  showPasswordScreen();
}

void loop() {

  if (digitalRead(BTN1) == LOW) {

    entered[count] = 1;
    count++;

    showPasswordScreen();

    delay(250);
    while (digitalRead(BTN1) == LOW);
  }

  if (digitalRead(BTN2) == LOW) {

    entered[count] = 2;
    count++;

    showPasswordScreen();

    delay(250);
    while (digitalRead(BTN2) == LOW);
  }

  if (count >= 4) {
    checkPassword();
  }
}